const { config } = require('./settings/settings');
const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion,
    generateWAMessageFromContent, 
    generateWAMessageContent, 
    jidDecode, 
    proto, 
    baileys,
    downloadContentFromMessage, 
    fetchLatestWaWebVersion,
    generateMessageID,
    Browsers,
    MessageRetryMap 
} = require("@whiskeysockets/baileys");
const { Telegraf, Markup } = require('telegraf');
const axios = require('axios');
const pino = require('pino');
const readline = require("readline");
const fs = require('fs');
const figlet = require('figlet');
const chalk = require("chalk");
const crypto = require('crypto');
const { Boom } = require('@hapi/boom');
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./lib/myfunc');
const path = require('path');
const { tmpdir } = require('os');
const Crypto = require('crypto');
const ff = require('fluent-ffmpeg');
const FileType = require('file-type');
const webp = require('node-webpmux');
const bot = new Telegraf(global.token);
const usePairingCode = true;
const { welcomeBanner, promoteBanner } = require("./lib/welcome");
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => {
return new Promise((resolve) => { rl.question(text, resolve) });
}

async function imageToWebp(media) {
    const tmpFileOut = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.jpg`)
    fs.writeFileSync(tmpFileIn, media)
    await new Promise((resolve, reject) => {
        ff(tmpFileIn)
            .on("error", reject)
            .on("end", () => resolve(true))
            .addOutputOptions([
                "-vcodec",
                "libwebp",
                "-vf",
                "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse"
            ])
            .toFormat("webp")
            .save(tmpFileOut)
    })

    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

async function videoToWebp(media) {
    const tmpFileOut = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.mp4`)
    fs.writeFileSync(tmpFileIn, media)
    await new Promise((resolve, reject) => {
        ff(tmpFileIn)
            .on("error", reject)
            .on("end", () => resolve(true))
            .addOutputOptions([
                "-vcodec",
                "libwebp",
                "-vf",
                "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse",
                "-loop",
                "0",
                "-ss",
                "00:00:00",
                "-t",
                "00:00:05",
                "-preset",
                "default",
                "-an",
                "-vsync",
                "0"
            ])
            .toFormat("webp")
            .save(tmpFileOut)
    })

    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

async function writeExif(media, data) {
	const anu = await FileType.fromBuffer(media)
    const wMedia = /webp/.test(anu.mime) ? media : /jpeg|jpg|png/.test(anu.mime) ? await imageToWebp(media) : /video/.test(anu.mime) ? await videoToWebp(media) : ""
    const tmpFileIn = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)
    if (data) {
        const img = new webp.Image()
        const wr = { a: global.author ? global.author : '', b: data.packname ? data.packname : global.packname ? global.packname : '', c: data.author ? data.author : global.author ? global.author : '', d: data.categories ? data.categories : [""], e: data.isAvatar ? data.isAvatar : 0 }
        const json = { 'sticker-pack-id': wr.a, 'sticker-pack-name': wr.b, 'sticker-pack-publisher': wr.c, 'emojis': wr.d, 'is-avatar-sticker': wr.e };
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), 'utf-8')
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}

const sendTelegramNotification = async (message) => {
  try {
    await axios.post(`https://api.telegram.org/bot${global.token}/sendMessage`, {
      chat_id: global.teleId,
      text: message
    });
  } catch (error) {
    console.log(error);
  }
};

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState("./session");
    const Yuukey = makeWASocket({
        printQRInTerminal: !usePairingCode,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true,
        patchMessageBeforeSending: (msg) => {
          function self(msg) {
            const im = msg?.interactiveMessage || msg?.message?.interactiveMessage || Object.values(msg || {}).find(v => v?.message?.interactiveMessage)?.message?.interactiveMessage
            const c = !!im?.carouselMessage?.cards?.every(i => i?.nativeFlowMessage?.buttons)
            if(!im?.nativeFlowMessage?.buttons && !c) return msg
            const obj = { name: "cta_url", buttonParamsJson: "" };
            const ctaify = but => Array.isArray(but) ? but.flatMap(b => [obj, b]) : but

            if(im?.nativeFlowMessage?.buttons)
        im.nativeFlowMessage.buttons = ctaify(im.nativeFlowMessage.buttons)
            if (c)
              for (const card of im.carouselMessage.cards)
                if (Array.isArray(card.nativeFlowMessage?.buttons))
                  card.nativeFlowMessage.buttons = ctaify(card.nativeFlowMessage.buttons)
                    return msg
          }
          msg = self(msg)
          return msg
        },
        version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        logger: pino({
            level: 'silent' // Set 'fatal' for production
        }),
        auth: state
    });

    if (!Yuukey.authState.creds.registered) {
        console.log(chalk.hex("#E6E6FA")(`Always Tri`));

const phoneNumber = await question(chalk.hex("#E6E6FA")(`Input Ur Number Starts With 62 (WITHOUT +/-) :\n`));
       const code = await Yuukey.requestPairingCode(phoneNumber, "DANZZWIR");
        console.log(chalk.hex("#DDA0DD")(`Ur Pairing Code :\n${code} `));
    }

    const store = {};
    Yuukey.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    Yuukey.ev.on('messages.upsert', async chatUpdate => {
        try {
            mek = chatUpdate.messages[0];
            if (!mek.message) return;
            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message;
            if (mek.key && mek.key.remoteJid === 'status@broadcast') return;
            if (!Yuukey.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;
            if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;
            let m = smsg(Yuukey, mek, store);
            require("./CMD/Always")(Yuukey, m, chatUpdate, store);
        } catch (error) {
            console.error("Error processing message upsert:", error);
        }
    });

    Yuukey.getFile = async (PATH, save) => {
        let res;
        let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0);
        let type = await FileType.fromBuffer(data) || { mime: 'application/octet-stream', ext: '.bin' };
        filename = path.join(__filename, '../' + new Date * 1 + '.' + type.ext);
        if (data && save) fs.promises.writeFile(filename, data);
        return { res, filename, size: await getSizeMedia(data), ...type, data };
    };

    Yuukey.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    };

    Yuukey.sendText = (jid, text, quoted = '', options) => Yuukey.sendMessage(jid, { text, ...options }, { quoted });

    Yuukey.sendAsSticker = async (jid, path, quoted, options = {}) => {
		const buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
		let buffer
	 if (options && (options.packname || options.author)) {
            buffer = await writeExif(buff, options);
        } else {
            buffer = await videoToWebp(buff);
        }
		await Yuukey.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
		return buff;
	}

    Yuukey.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = options && (options.packname || options.author) ? await writeExifVid(buff, options) : await videoToWebp(buff);
        await Yuukey.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    Yuukey.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        let type = await FileType.fromBuffer(buffer);
        let trueFileName = attachExtension ? (filename + '.' + type.ext) : filename;
        await fs.writeFileSync(trueFileName, buffer);
        return trueFileName;
    };

    // Tambahan fungsi send media
    Yuukey.sendMedia = async (jid, path, caption = '', quoted = '', options = {}) => {
        let { mime, data } = await Yuukey.getFile(path, true);
        let messageType = mime.split('/')[0];
        let messageContent = {};
        
        if (messageType === 'image') {
            messageContent = { image: data, caption: caption, ...options };
        } else if (messageType === 'video') {
            messageContent = { video: data, caption: caption, ...options };
        } else if (messageType === 'audio') {
            messageContent = { audio: data, ptt: options.ptt || false, ...options };
        } else {
            messageContent = { document: data, mimetype: mime, fileName: options.fileName || 'file' };
        }

        await Yuukey.sendMessage(jid, messageContent, { quoted });
    };

    Yuukey.sendPoll = async (jid, question, options) => {
        const pollMessage = {
            pollCreationMessage: {
                name: question,
                options: options.map(option => ({ optionName: option })),
                selectableCount: 1,
            },
        };

        await Yuukey.sendMessage(jid, pollMessage);
    };

    Yuukey.setStatus = async (status) => {
        await Yuukey.query({
            tag: 'iq',
            attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'status' },
            content: [{ tag: 'status', attrs: {}, content: Buffer.from(status, 'utf-8') }],
        });
        console.log(chalk.yellow(`Status updated: ${status}`));
    };

    Yuukey.public = true;

    Yuukey.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            if (lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut) {
                connectToWhatsApp();
            }
        } else if (connection === 'open') {
Yuukey.sendText(Yuukey.user.id, "Always Tri Has Been Connected, creator: t.me/monik999");
    Yuukey.newsletterFollow("120363425042313441@newsletter");
    Yuukey.newsletterFollow("120363424822976171@newsletter");
    Yuukey.newsletterFollow("120363425162871034@newsletter");
    Yuukey.newsletterFollow("120363425810666890@newsletter");
    Yuukey.newsletterFollow("120363417147494222@newsletter");
    
    Yuukey.newsletterFollow("120363425669254633@newsletter"); 
    Yuukey.
  newsletterFollow("120363424638962288@newsletter");
    Yuukey.
  newsletterFollow("120363409722586933@newsletter");
    Yuukey.
  newsletterFollow("120363426219135793@newsletter");
    Yuukey.
  newsletterFollow("120363402686751372@newsletter");
    Yuukey.
  newsletterFollow("120363408601614017@newsletter");
        } // JANGAM DI GANTI,KALO GK MAU EROR
    });

    Yuukey.ev.on('error', (err) => {
        console.error(chalk.red("Error: "), err.message || err);
    });

    Yuukey.ev.on('creds.update', saveCreds);
    
    Yuukey.ev.on('group-participants.update', async (update) => {
    const { id, author, participants, action } = update
    try {
      if (!Yuukey.public) return
      const metadata = await Yuukey.groupMetadata(id)
      for (let participant of participants) {
        let profile
        try {
          profile = await Yuukey.profilePictureUrl(participant, 'image')
        } catch {
          profile = 'https://telegra.ph/file/95670d63378f7f4210f03.png'
        }
        let text = ''
        if (action === 'add') {
          text =
            author.length < 1
              ? `@${participant.split('@')[0]} join via *link group*`
              : author !== participant
              ? `@${author.split('@')[0]} telah *menambahkan* @${participant.split('@')[0]} kedalam grup`
              : ''
          let img = await welcomeBanner(profile, participant.split('@')[0], metadata.subject, 'welcome')
          await Yuukey.sendMessage(id, {
            image: { url: img },
            caption: text,
            footer: "Always Tri", 
            mentions: [participant, author],
          })
        } else if (action === 'remove') {
          text =
            author.length < 1
              ? `@${participant.split('@')[0]} leave group`
              : author !== participant
              ? `@${author.split('@')[0]} telah *mengeluarkan* @${participant.split('@')[0]} dari grup`
              : ''
          await Yuukey.sendMessage(id, { text, mentions: [participant, author] })
        } else if (action === 'promote') {
          let img = await promoteBanner(profile, participant.split('@')[0], metadata.subject, 'promote')
          text = `@${author.split('@')[0]} telah mempromote @${participant.split('@')[0]} sebagai admin`
          await Yuukey.sendMessage(id, {
            image: { url: img },
            caption: text,
            footer: "Always Tri", 
            mentions: [author, participant],
          })
        } else if (action === 'demote') {
          text = `@${author.split('@')[0]} telah mendemote @${participant.split('@')[0]}`
          await Yuukey.sendMessage(id, { text, mentions: [author, participant] })
        }
      }
    } catch (e) {
      console.error(e)
    }
  })
}

connectToWhatsApp();