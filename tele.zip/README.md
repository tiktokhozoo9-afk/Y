#Viper 
Developer *Saka-Urbans*
Harga Script *Rp.10.000*
Name Script *Viper 1.0.0*

_Peringatan ⚠️_
#jangan menggunakan bug secara sembarangan ke orang yang tidak bersalah, Jangan bermain curang terhadap Script 

`JAVASCRIPT` *BUG WHATSAPP*